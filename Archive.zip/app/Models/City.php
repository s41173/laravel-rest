<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class City extends BaseModel
{
    protected $table = 'kabupaten';

    public $timestamps = false;

    protected $fillable = [];

}
